﻿namespace ManejoPresupuesto.Models
{
    public class ResumenMontosViewModel
    {
        public decimal Ingresos { get; set; }
        public decimal Gastos {  get; set; }    
        public decimal Total { get; set; }

    }
}
