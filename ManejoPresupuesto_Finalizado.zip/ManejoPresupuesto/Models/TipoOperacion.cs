﻿namespace ManejoPresupuesto.Models
{
    public enum TipoOperacion
    {
         Ingreso =1,
         Gasto=2
    }
}
