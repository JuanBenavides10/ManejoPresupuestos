﻿namespace ManejoPresupuesto.Models
{
    public enum SubMenuTransacciones
    {
        Diario,Semanal,Mensual,Excel,Calendario 
    }
}
